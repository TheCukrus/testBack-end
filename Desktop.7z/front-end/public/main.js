import App from "./components/App.js";

ReactDOM.render(React.createElement(App, null, null), document.getElementById("div1"));